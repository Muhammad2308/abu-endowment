@extends('layouts.admin')

@section('title', 'Manage Notifications')

@section('content')
    <h2 class="text-2xl font-bold text-gray-900 dark:text-white">Manage Notifications</h2>
    <p class="mt-2 text-gray-600 dark:text-gray-300">This page will contain tools to send SMS and email notifications. (Coming soon)</p>
@endsection 