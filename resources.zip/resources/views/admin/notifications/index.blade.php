@extends('layouts.admin')

@section('title', 'Notifications Dashboard')

@section('content')
    @livewire('admin.notifications.dashboard')
@endsection
