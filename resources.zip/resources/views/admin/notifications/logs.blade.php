@extends('layouts.admin')

@section('title', 'Email Logs')

@section('content')
    @livewire('admin.notifications.email-logs')
@endsection
