@extends('layouts.admin')

@section('title', 'Create Email Template')

@section('content')
    @livewire('admin.notifications.template-form')
@endsection
