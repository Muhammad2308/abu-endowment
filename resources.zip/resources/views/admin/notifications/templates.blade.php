@extends('layouts.admin')

@section('title', 'Email Templates')

@section('content')
    @livewire('admin.notifications.template-list')
@endsection
