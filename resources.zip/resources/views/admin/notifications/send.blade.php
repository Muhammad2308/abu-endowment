@extends('layouts.admin')

@section('title', 'Send Notification')

@section('content')
    @livewire('admin.notifications.send-email')
@endsection
