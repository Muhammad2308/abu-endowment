<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    // Ozeki SMS Gateway Configuration
    'ozeki' => [
        'username' => env('OZEKI_USERNAME', 'http_user'),
        'password' => env('OZEKI_PASSWORD', 'qwe123'),
        'api_url' => env('OZEKI_API_URL', 'http://127.0.0.1:9509/api?action=rest'),
        'enabled' => env('SMS_VERIFICATION_ENABLED', true),
    ],

    'kudi' => [
        'token' => env('KUDI_SMS_KEY', 'iC4HrtdX0zlSMRJmIkNu9ZfL61pYVFTvQgs7GhOEjnAWPe3UDbxwycB2q8oaK5'),
        'url' => env('KUDI_SMS_URL', 'https://my.kudisms.net/api/intcomposesms'),
    ],

    // Squad Payment Configuration
    'squad' => [
        'secret_key' => env('SQUAD_SECRET_KEY', ''),
        'base_url'   => env('SQUAD_API_URL', env('SQUAD_BASE_URL', 'https://api-d.squadco.com')),
    ],

    // Paystack Configuration
    'paystack' => [
        'public_key' => env('PAYSTACK_PUBLIC_KEY'),
        'secret_key' => env('PAYSTACK_SECRET_KEY'),
        'webhook_secret' => env('PAYSTACK_WEBHOOK_SECRET'),
        'url' => env('PAYSTACK_URL', 'https://api.paystack.co'),
    ],

    // Google OAuth Configuration
    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        'redirect' => env('GOOGLE_REDIRECT_URI'),
    ],

];
