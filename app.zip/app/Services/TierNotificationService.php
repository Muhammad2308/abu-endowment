<?php

namespace App\Services;

use App\Models\Donation;
use App\Models\Donor;
use App\Models\DonorTier;
use App\Models\EmailTemplate;
use App\Models\EmailLog;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class TierNotificationService
{
    public function handleDonationTierCheck(Donation $donation): void
    {
        try {
            $donor = $donation->donor ?? Donor::find($donation->donor_id);
            if (!$donor) {
                return;
            }

            $total = Donation::where('donor_id', $donor->id)
                ->where('status', 'completed')
                ->sum('amount');

            $newTier = DonorTier::where('is_active', true)
                ->where('min_amount', '<=', $total)
                ->orderBy('sort_order', 'desc')
                ->first();

            if (!$newTier) {
                return;
            }

            $oldTierId = $donor->donor_tier_id;

            // Update donor tier regardless (keeps it in sync)
            $donor->update(['donor_tier_id' => $newTier->id]);

            // Only send notification if the tier actually changed
            if ($oldTierId === $newTier->id || !$donor->email) {
                return;
            }

            $template = EmailTemplate::where('donor_tier_id', $newTier->id)
                ->where('is_active', true)
                ->first();

            if (!$template) {
                Log::info('No active email template for tier', [
                    'tier_id'   => $newTier->id,
                    'tier_name' => $newTier->name,
                ]);
                return;
            }

            $this->sendTierEmail($donor, $newTier, $template, $donation, (float) $total);

        } catch (\Exception $e) {
            Log::error('TierNotificationService error', [
                'donation_id' => $donation->id,
                'error'       => $e->getMessage(),
            ]);
        }
    }

    private function sendTierEmail(
        Donor $donor,
        DonorTier $tier,
        EmailTemplate $template,
        Donation $donation,
        float $total
    ): void {
        $donorName = trim("{$donor->surname} {$donor->name}") ?: $donor->email;

        $variables = [
            'donor_name'   => $donorName,
            'tier_name'    => $tier->name,
            'total_amount' => number_format($total, 2),
            'amount'       => number_format((float) $donation->amount, 2),
            'reference'    => $donation->payment_reference ?? '',
        ];

        $bodyHtml = $this->replaceVariables($template->body_html ?? '', $variables);
        $subject  = $this->replaceVariables(
            $template->subject ?: "Congratulations! You've reached {$tier->name}",
            $variables
        );

        $log = EmailLog::create([
            'recipient_email' => $donor->email,
            'recipient_name'  => $donorName,
            'template_id'     => $template->id,
            'status'          => 'pending',
            'sent_at'         => null,
        ]);

        try {
            Mail::html($bodyHtml, function ($message) use ($donor, $subject) {
                $message->to($donor->email)
                        ->subject($subject)
                        ->from(
                            config('mail.from.address', 'noreply@abu-endowment.edu.ng'),
                            config('mail.from.name', 'ABU Endowment Fund')
                        );
            });

            $log->update(['status' => 'sent', 'sent_at' => now()]);

            Log::info('Tier notification email sent', [
                'donor_id'  => $donor->id,
                'tier_name' => $tier->name,
                'email'     => $donor->email,
            ]);
        } catch (\Exception $e) {
            $log->update([
                'status'        => 'failed',
                'error_message' => $e->getMessage(),
            ]);
            Log::error('Failed to send tier notification email', [
                'donor_id' => $donor->id,
                'error'    => $e->getMessage(),
            ]);
        }
    }

    private function replaceVariables(string $text, array $variables): string
    {
        foreach ($variables as $key => $value) {
            $text = str_replace("{{{$key}}}", $value, $text);
            $text = str_replace("{{ {$key} }}", $value, $text);
        }
        return $text;
    }
}
