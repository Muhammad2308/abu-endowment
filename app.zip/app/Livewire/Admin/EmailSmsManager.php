<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class EmailSmsManager extends Component
{
    public function render()
    {
        return view('livewire.admin.email-sms-manager');
    }
}
