<?php

namespace App\Livewire\Admin;

use App\Models\Project;
use App\Models\ProjectPhoto;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Storage;

class AddProjectPhotos extends Component
{
    use WithFileUploads;

    public $showModal = false;
    public Project $project;
    public $photos = [];
    public $refreshKey = 0; // Force refresh trigger

    protected $rules = [
        'photos.*' => 'required|image|max:5120', // 5MB max per image
    ];

    protected $messages = [
        'photos.*.required' => 'Please select at least one photo.',
        'photos.*.image' => 'Each file must be an image.',
        'photos.*.max' => 'Each image size must not exceed 5MB.',
    ];

    public function mount()
    {
        $this->project->load('photos');
    }

    public function open()
    {
        $this->resetForm();
        $this->project->load('photos'); // Ensure photos are loaded
        $this->showModal = true;
    }

    public function closeModal()
    {
        $this->showModal = false;
        $this->resetForm();
    }

    public function resetForm()
    {
        $this->photos = [];
        $this->resetValidation();
    }

    public function savePhotos()
    {
        $this->validate();

        try {
            $savedPhotoIds = [];
            
            foreach ($this->photos as $photo) {
                $photoPath = $photo->store('projects/photos', 'public');
                
                \Log::info('Saving project photo', [
                    'project_id' => $this->project->id,
                    'photo_path' => $photoPath,
                    'full_storage_path' => storage_path('app/public/' . $photoPath),
                    'file_exists' => file_exists(storage_path('app/public/' . $photoPath))
                ]);
                
                $projectPhoto = ProjectPhoto::create([
                    'project_id' => $this->project->id,
                    'body_image' => $photoPath,
                ]);
                
                $savedPhotoIds[] = $projectPhoto->id;
                
                \Log::info('Project photo created', [
                    'photo_id' => $projectPhoto->id,
                    'body_image' => $projectPhoto->body_image,
                    'image_url' => $projectPhoto->image_url
                ]);
            }

            // Clear temporary uploads immediately
            $this->reset('photos');
            
            // Force refresh the project photos relationship
            // Clear the relationship cache and reload
            $this->project->refresh();
            $this->project->unsetRelation('photos');
            $this->project->load('photos');
            
            // Increment refresh key to force Livewire to re-render
            $this->refreshKey++;
            
            \Log::info('Project refreshed after photo save', [
                'project_id' => $this->project->id,
                'photos_count' => $this->project->photos->count(),
                'photo_ids' => $this->project->photos->pluck('id')->toArray(),
                'photo_urls' => $this->project->photos->map(function($p) {
                    return [
                        'id' => $p->id,
                        'body_image' => $p->body_image,
                        'image_url' => $p->image_url
                    ];
                })->toArray(),
                'refresh_key' => $this->refreshKey
            ]);
            
            // Dispatch event to notify other components and force refresh
            $this->dispatch('photos-updated', projectId: $this->project->id);
            $this->dispatch('$refresh');

            session()->flash('message', 'Photos added successfully!');
        } catch (\Exception $e) {
            \Log::error('Photo upload error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            session()->flash('error', 'Error adding photos: ' . $e->getMessage());
        }
    }

    public function deletePhoto($photoId)
    {
        try {
            $photo = ProjectPhoto::findOrFail($photoId);
            
            if ($photo->body_image) {
                Storage::disk('public')->delete($photo->body_image);
            }
            
            $photo->delete();
            
            // Force refresh the project photos relationship
            $this->project->refresh();
            $this->project->unsetRelation('photos');
            $this->project->load('photos');
            
            // Increment refresh key to force Livewire to re-render
            $this->refreshKey++;
            
            $this->dispatch('$refresh');
            session()->flash('message', 'Photo deleted successfully!');
            
        } catch (\Exception $e) {
            session()->flash('error', 'Error deleting photo: ' . $e->getMessage());
        }
    }

    public function render()
    {
        // Always reload photos to ensure we have the latest data
        if ($this->project->exists) {
            $this->project->load('photos');
        }
        
        return view('livewire.admin.add-project-photos');
    }
}