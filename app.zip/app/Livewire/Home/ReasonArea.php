<?php

namespace App\Livewire\Home;

use Livewire\Component;

class ReasonArea extends Component
{
    public function render()
    {
        return view('livewire.home.reason-area');
    }
}
