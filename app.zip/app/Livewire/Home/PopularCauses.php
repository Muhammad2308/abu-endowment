<?php

namespace App\Livewire\Home;

use Livewire\Component;

class PopularCauses extends Component
{
    public function render()
    {
        return view('livewire.home.popular-causes');
    }
}
