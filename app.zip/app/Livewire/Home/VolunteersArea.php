<?php

namespace App\Livewire\Home;

use Livewire\Component;

class VolunteersArea extends Component
{
    public function render()
    {
        return view('livewire.home.volunteers-area');
    }
}
