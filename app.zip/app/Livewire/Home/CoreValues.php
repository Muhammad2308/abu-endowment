<?php

namespace App\Livewire\Home;

use Livewire\Component;

class CoreValues extends Component
{
    public function render()
    {
        return view('livewire.home.core-values');
    }
}
