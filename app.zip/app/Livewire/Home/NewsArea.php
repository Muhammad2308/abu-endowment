<?php

namespace App\Livewire\Home;

use Livewire\Component;

class NewsArea extends Component
{
    public function render()
    {
        return view('livewire.home.news-area');
    }
}
