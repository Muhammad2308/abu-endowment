<?php

namespace App\Livewire\Home;

use Livewire\Component;

class SliderArea extends Component
{
    public function render()
    {
        return view('livewire.home.slider-area');
    }
}
