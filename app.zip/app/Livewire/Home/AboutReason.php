<?php

namespace App\Livewire\Home;

use Livewire\Component;

class AboutReason extends Component
{
    public function render()
    {
        return view('livewire.home.about-reason');
    }
}
