<?php

namespace App\Livewire\Home;

use Livewire\Component;

class LatestActivities extends Component
{
    public function render()
    {
        return view('livewire.home.latest-activities');
    }
}
